Description
-----------

Gif89Encoder is a Java (JDK 1.1 level) class library for writing GIF files.
In addition to the usual options, it supports animation and comments.  Point
your browser to the javadocs in the present distribution's 'doc' directory for
more info.

Installation
------------

It's suggested you unpack the ZIP to the location where you want to install the
encoder, taking care to preserve internal directories.  (The installation tester
and Java docs make a couple of relative-path assumptions.)  As a Java
programmer, you know how to put a JAR on your CLASSPATH, etc., so I'm not going
to belabor it.  The distribution should be fairly self-explanatory.  If you're on
Windows and want to run 'runtest.bat', make sure you edit it first to point to your
Java runtime installation.

Legal
-----

Since Gif89Encoder includes significant sections of code from Jef Poskanzer's
GifEncoder.java, I'm including its notice in this distribution as requested (appended
below).

As for my part of the code, I hereby release it, on a strictly "as is" basis,
to the public domain.

J. M. G. Elliott
15-Jul-2000

--------------------- from Jef Poskanzer's GifEncoder.java ---------------------

// GifEncoder - write out an image as a GIF
//
// Transparency handling and variable bit size courtesy of Jack Palevich.
//
// Copyright (C) 1996 by Jef Poskanzer <jef@acme.com>.  All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
// 1. Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
// 2. Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
//
// THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
// OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
// LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
// OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
// SUCH DAMAGE.
//
// Visit the ACME Labs Java page for up-to-date versions of this and other
// fine Java utilities: http://www.acme.com/java/